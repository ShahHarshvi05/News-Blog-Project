<?php include 'header.php'; 
$id = $_GET['id'];
$sql = "select post.post_id, post.title, post.description,post.author, post.category, post.post_date, post.post_img, user.username, category.category_name from post 
LEFT JOIN category on post.category = category.category_id
left join user on post.author = user.user_id  where post.post_id  = '$id'" ;
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result) == 1){
    while($row = mysqli_fetch_assoc($result)){
        $post_id = $row['post_id'];
        $title = $row['title'];
        $description = $row['description'];
        $category = $row['category_name'];
        $author = $row['username'];
        $post_date = $row['post_date'];
        $post_img = $row['post_img'];
        $category_id = $row['category'];
        $author_id = $row['author'];
    }
}
?>
    <div id="main-content">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                  <!-- post-container -->
                    <div class="post-container">
                        <div class="post-content single-post">
                            <h3><?php echo $title;?></h3>
                            <div class="post-information">
                                <span>
                                <i class="fa fa-tags" aria-hidden="true"></i>
                                <a href='category.php?id=<?php echo $category_id ;?>'><?php echo $category;?></a>
                                </span>
                                <span>
                                    <i class="fa fa-user" aria-hidden="true"></i>
                                    <a href='author.php?id=<?php echo $author_id;?>'><?php echo $author;?></a>
                                </span>
                                <span>
                                    <i class="fa fa-calendar" aria-hidden="true"></i>
                                    <?php echo $post_date;?>
                                </span>
                            </div>
                            <img class="single-feature-image" src="admin/upload/<?php echo $post_img;?>" alt="" height = "400px"/>
                            <p class="description">
                            <?php echo $description;?>
                            </p>
                        </div>
                    </div>
                    <!-- /post-container -->
                </div>
                <?php include 'sidebar.php'; ?>
            </div>
        </div>
    </div>
<?php include 'footer.php'; ?>
