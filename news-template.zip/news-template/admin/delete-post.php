<?php

include 'config.php'; 

$post_id = $_GET['id'];
$sql1="select * from post where post_id = '$post_id'";
$result = mysqli_query($conn, $sql1);
$row = mysqli_fetch_assoc($result);
unlink("upload/".$row['post_img']);
$sql = "delete from post where post_id = '$post_id'";
if(mysqli_query($conn, $sql))

    header('location: post.php');
mysqli_close($conn);
?>