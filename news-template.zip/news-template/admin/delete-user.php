<?php

include 'config.php';
if($_SESSION['user_role'] == 0 ){
    header('location: post.php');
}
$user_id = $_GET['id'];
$sql = "delete from user where user_id = '$user_id'";
if(mysqli_query($conn, $sql))

    header('location: users.php');
mysqli_close($conn);
?>