<?php 
$conn = mysqli_connect("localhost","root","", "new-cms") or die('connection failed' . mysqli_error());
?>