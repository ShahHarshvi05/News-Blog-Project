<?php 
include 'config.php';
if(isset($_POST['submit'])){
    $post_id = mysqli_real_escape_string($conn, $_POST['post_id']);
    $title = mysqli_real_escape_string($conn, $_POST['post_title']);
    $description = mysqli_real_escape_string($conn, $_POST['postdesc']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);

if(empty($_FILES['new-image']['name'])){
    $file_name = $_POST['old-image'];

}else{
    if(isset($_FILES['new-image'])){
        $errors = array();
        $file_name = $_FILES['new-image']['name'];
        $file_size = $_FILES['new-image']['size'];
        $file_tmp = $_FILES['new-image']['tmp_name'];
        $file_type = $_FILES['new-image']['type'];
        $tmp_ext = explode('.',$file_name);
        $file_ext = end($tmp_ext);
        $extension = array("jpeg","jpg","png");
        if(in_array($file_ext,$extension) === false)
        {
            $errors[]= "upload only image file for eg jpeg , png , jpg";
        }
        if($file_size > 2097152)
        {
            $errors[]= "Image should be of less than 2MB";
        }
        if(empty($errors) == true){
            move_uploaded_file($file_tmp, "upload/".$file_name);
        }else{
            print_r($errors);
            die();
        }
        }

}
$sql = "update post set title = '$title', 
description = '$description', 
category = '$category', 
post_img = '$file_name'
where post_id = '$post_id'";
if(mysqli_query($conn, $sql)){
    header('location: post.php');
}
}
?>