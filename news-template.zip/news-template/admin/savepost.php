<?php 
include 'config.php';
if(isset($_FILES['image'])){
$errors = array();
$file_name = $_FILES['image']['name'];
$file_size = $_FILES['image']['size'];
$file_tmp = $_FILES['image']['tmp_name'];
$file_type = $_FILES['image']['type'];
$tmp_ext = explode('.',$file_name);
$file_ext = end($tmp_ext);
$extension = array("jpeg","jpg","png");
if(in_array($file_ext,$extension) === false)
{
    $errors[]= "upload only image file for eg jpeg , png , jpg";
}
if($file_size > 2097152)
{
    $errors[]= "Image should be of less than 2MB";
}
if(empty($errors) == true){
    move_uploaded_file($file_tmp, "upload/".$file_name);
}else{
    print_r($errors);
    die();
}
}
session_start();
$title= mysqli_real_escape_string($conn, $_POST['post_title']);
$description=mysqli_real_escape_string($conn, $_POST['postdesc']);
$category=mysqli_real_escape_string($conn, $_POST['category']);
$date = date('d,M,Y');
$author = $_SESSION['user_id'];
//$image=mysqli_real_escape_string($conn, $_POST['fileToUpload']);

$sql = "insert into post(title, description, category, post_date, author, post_img)
values('$title', '$description', '$category', '$date', '$author', '$file_name')";
if(mysqli_query($conn, $sql)){
    header('location: post.php');
}else{
    echo "<div class='alert alert-danger'>Query Failes</div>";
}

?>
